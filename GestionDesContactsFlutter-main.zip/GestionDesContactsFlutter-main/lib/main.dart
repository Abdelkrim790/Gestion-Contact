import 'package:flutter/material.dart';
import 'contacts.dart';
import 'database_helper.dart';
import 'Contact.dart';
import 'settings.dart';

// Notifier global pour changer le thème de l'application
final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);

void main() {
  runApp(const MyApp());
}

// Widget principal de l'application
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Écoute des changements de thème
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, ThemeMode currentMode, __) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: ThemeData.light(),       // Thème clair
          darkTheme: ThemeData.dark(),    // Thème sombre
          themeMode: currentMode,         // Thème actif
          home: const PagePrincipale(),
        );
      },
    );
  }
}

// Page principale pour ajouter un nouveau contact
class PagePrincipale extends StatefulWidget {
  const PagePrincipale({super.key});

  @override
  State<PagePrincipale> createState() => _PagePrincipaleState();
}

class _PagePrincipaleState extends State<PagePrincipale> {
  // Contrôleurs pour les champs de texte
  final TextEditingController nomController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController telController = TextEditingController();

  // Regex pour valider l'email
  final RegExp emailRegExp =
  RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');

  // Fonction pour ajouter un nouveau contact
  Future<void> _addContact() async {
    final String nom = nomController.text.trim();
    final String email = emailController.text.trim();
    final String tel = telController.text.trim();

    // Validation des champs
    if (nom.isEmpty || email.isEmpty || tel.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Veuillez remplir tous les champs')),
      );
      return;
    }

    if (!emailRegExp.hasMatch(email)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Email invalide')),
      );
      return;
    }

    if (tel.length != 8 || int.tryParse(tel) == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Téléphone doit contenir 8 chiffres')),
      );
      return;
    }

    // Création et insertion du contact dans la base
    final newContact = Contact(nom: nom, email: email, tel: tel);
    await DatabaseHelper.instance.insertContact(newContact);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Contact ajouté avec succès')),
    );

    // Réinitialisation des champs
    nomController.clear();
    emailController.clear();
    telController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Barre supérieure avec bouton paramètres
      appBar: AppBar(
        title: const Text('Gestion de Contacts'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'Paramètres',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const SettingsPage(),
                ),
              );
            },
          ),
        ],
      ),

      // Corps de la page
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [

            // Card pour ajouter un contact
            Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              elevation: 4,
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [

                    // Champ Nom
                    TextField(
                      controller: nomController,
                      decoration: const InputDecoration(
                        labelText: 'Nom',
                        prefixIcon: Icon(Icons.person),
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Champ Email
                    TextField(
                      controller: emailController,
                      decoration: const InputDecoration(
                        labelText: 'Email',
                        prefixIcon: Icon(Icons.email),
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const SizedBox(height: 12),

                    // Champ Téléphone
                    TextField(
                      controller: telController,
                      decoration: const InputDecoration(
                        labelText: 'Téléphone',
                        prefixIcon: Icon(Icons.phone),
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.number,
                      maxLength: 8,
                    ),
                    const SizedBox(height: 16),

                    // Bouton Enregistrer
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _addContact,
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text(
                          'Enregistrer',
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Bouton pour accéder à la liste des contacts
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ContactsListPage(),
                    ),
                  );
                },
                icon: const Icon(Icons.list),
                label: const Text('Liste des contacts'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  textStyle: const TextStyle(fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
