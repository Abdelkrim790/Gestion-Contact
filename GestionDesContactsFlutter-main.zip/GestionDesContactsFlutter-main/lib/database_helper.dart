import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'Contact.dart';

// Classe pour gérer la base de données SQLite
class DatabaseHelper {
  // Singleton pour accéder facilement à la base
  static final DatabaseHelper instance = DatabaseHelper.init_();
  static Database? _database;

  DatabaseHelper.init_();

  // Accès à la base de données
  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await initDB('contacts.db');
    return _database!;
  }

  // Initialisation de la base de données
  Future<Database> initDB(String filePath) async {
    final dbpath = await getDatabasesPath();
    final path = join(dbpath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  // Création de la table contacts
  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE contacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom TEXT NOT NULL,
        email TEXT NOT NULL,
        tel TEXT NOT NULL,
        favorite INTEGER NOT NULL DEFAULT 0
      )
    ''');
  }

  // CRUD

  // Ajouter un contact
  Future<int> insertContact(Contact contact) async {
    final db = await instance.database;
    return await db.insert('contacts', contact.toMap());
  }

  // Lire tous les contacts
  Future<List<Contact>> getContacts() async {
    final db = await instance.database;
    final result = await db.query('contacts');
    return result.map((map) => Contact.fromMap(map)).toList();
  }

  // Mettre à jour un contact
  Future<int> updateContact(Contact contact) async {
    final db = await instance.database;
    return await db.update(
      'contacts',
      contact.toMap(),
      where: 'id = ?',
      whereArgs: [contact.id],
    );
  }

  // Supprimer un contact
  Future<int> deleteContact(int id) async {
    final db = await instance.database;
    return await db.delete(
      'contacts',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Mettre à jour le statut favori d'un contact
  Future<int> updateFavorite(int id, int isFavorite) async {
    final db = await database;
    return await db.update(
      'contacts',
      {'favorite': isFavorite},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Supprimer tous les contacts
  Future<int> deleteAllContacts() async {
    final db = await database;
    return await db.delete('contacts');
  }
}
