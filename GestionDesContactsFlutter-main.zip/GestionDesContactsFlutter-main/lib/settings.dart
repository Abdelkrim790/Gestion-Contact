import 'package:flutter/material.dart';
import 'database_helper.dart';
import 'main.dart'; // pour themeNotifier global

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  // Affiche un dialogue de confirmation pour supprimer tous les contacts
  Future<void> _confirmDeleteAll(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Text('Supprimer tous les contacts'),
        content: const Text(
          'Êtes-vous sûr de vouloir supprimer tous les contacts ? Cette action est irréversible.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Annuler'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Supprimer'),
          ),
        ],
      ),
    );

    // Si confirmé, supprime tous les contacts et affiche un SnackBar
    if (confirmed == true) {
      await DatabaseHelper.instance.deleteAllContacts();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tous les contacts ont été supprimés')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Paramètres')),

      // Liste des options de paramètres
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Toggle mode sombre / clair
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ValueListenableBuilder<ThemeMode>(
              valueListenable: themeNotifier,
              builder: (context, currentMode, _) {
                return SwitchListTile(
                  secondary: const Icon(Icons.dark_mode),
                  title: const Text('Mode sombre'),
                  subtitle: Text(currentMode == ThemeMode.dark ? 'Activé' : 'Désactivé'),
                  value: currentMode == ThemeMode.dark,
                  onChanged: (val) {
                    themeNotifier.value = val ? ThemeMode.dark : ThemeMode.light;
                  },
                );
              },
            ),
          ),

          const SizedBox(height: 16),

          // Supprimer tous les contacts
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ListTile(
              leading: const Icon(Icons.delete_forever, color: Colors.red),
              title: const Text('Supprimer tous les contacts'),
              subtitle: const Text('Cette action ne peut pas être annulée'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () => _confirmDeleteAll(context),
            ),
          ),

          const SizedBox(height: 32),

          // Crédits
          Center(
            child: Column(
              children: const [
                Text(
                  'Développé par:',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                SizedBox(height: 4),
                Text('Bacem Klali & Abdelkarim Yahyaoui'),
                SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
