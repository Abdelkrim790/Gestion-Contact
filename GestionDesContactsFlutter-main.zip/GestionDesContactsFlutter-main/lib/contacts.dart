import 'package:flutter/material.dart';
import 'database_helper.dart';
import 'Contact.dart';
import 'settings.dart';
import 'package:url_launcher/url_launcher.dart';

// Page pour afficher tous les contacts
class ContactsListPage extends StatefulWidget {
  @override
  _ContactsListPageState createState() => _ContactsListPageState();
}

class _ContactsListPageState extends State<ContactsListPage> {
  // Liste de contacts et filtres
  late Future<List<Contact>> _contactsFuture;
  List<Contact> _allContacts = [];
  List<Contact> _filteredContacts = [];
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadContacts();
    _searchController.addListener(_filterAndSortContacts);
  }

  // Charger les contacts depuis la base de données
  void _loadContacts() async {
    _contactsFuture = DatabaseHelper.instance.getContacts();
    final list = await _contactsFuture;
    setState(() {
      _allContacts = list;
      _filterAndSortContacts();
    });
  }

  // Filtrer et trier les contacts (recherche + favoris)
  void _filterAndSortContacts() {
    final query = _searchController.text.toLowerCase();
    _filteredContacts = _allContacts.where((contact) {
      return contact.nom.toLowerCase().contains(query);
    }).toList();

    // Trier : favoris d'abord, puis ordre alphabétique
    _filteredContacts.sort((a, b) {
      if (a.favorite != b.favorite) return b.favorite - a.favorite;
      return a.nom.toLowerCase().compareTo(b.nom.toLowerCase());
    });

    setState(() {});
  }

  // Basculer le statut favoris
  Future<void> _toggleFavorite(Contact c) async {
    int newValue = c.favorite == 1 ? 0 : 1;
    await DatabaseHelper.instance.updateFavorite(c.id!, newValue);
    c.favorite = newValue;
    _filterAndSortContacts();
  }

  // Grouper les contacts par première lettre, avec les favoris séparés
  Map<String, List<Contact>> _groupContacts() {
    Map<String, List<Contact>> groups = {};
    final favorites = _filteredContacts.where((c) => c.favorite == 1).toList();
    if (favorites.isNotEmpty) groups["⭐ Favoris"] = favorites;

    for (var contact in _filteredContacts.where((c) => c.favorite == 0)) {
      String letter = contact.nom[0].toUpperCase();
      groups.putIfAbsent(letter, () => []);
      groups[letter]!.add(contact);
    }
    return groups;
  }

  // Supprimer un contact
  Future<void> _deleteContact(int id) async {
    await DatabaseHelper.instance.deleteContact(id);
    _loadContacts();
  }

  // Dialog pour modifier un contact
  void _showUpdateDialog(Contact contact) {
    final nomController = TextEditingController(text: contact.nom);
    final emailController = TextEditingController(text: contact.email);
    final telController = TextEditingController(text: contact.tel);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Modifier Contact'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: nomController, decoration: const InputDecoration(labelText: 'Nom')),
            const SizedBox(height: 8),
            TextField(controller: emailController, decoration: const InputDecoration(labelText: 'Email')),
            const SizedBox(height: 8),
            TextField(controller: telController, decoration: const InputDecoration(labelText: 'Téléphone')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler')),
          ElevatedButton(
            onPressed: () async {
              await DatabaseHelper.instance.updateContact(
                Contact(
                  id: contact.id,
                  nom: nomController.text.trim(),
                  email: emailController.text.trim(),
                  tel: telController.text.trim(),
                  favorite: contact.favorite,
                ),
              );
              Navigator.pop(context);
              _loadContacts();
            },
            child: const Text('Enregistrer'),
          ),
        ],
      ),
    );
  }

  // Passer un appel à un contact
  Future<void> _callContact(String phone) async {
    final Uri uri = Uri(scheme: 'tel', path: phone);
    if (!await launchUrl(uri, mode: LaunchMode.platformDefault)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Impossible de passer l’appel')),
      );
    }
  }

  // Envoyer un email à un contact
  Future<void> _emailContact(String email) async {
    final Uri uri = Uri(
      scheme: 'mailto',
      path: email,
      query: Uri.encodeFull('subject=Hello&body=Bonjour'), // optionnel : sujet et corps
    );
    if (!await launchUrl(uri, mode: LaunchMode.platformDefault)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Impossible d’envoyer l’email')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final grouped = _groupContacts();

    return Scaffold(
      // AppBar avec accès aux paramètres
      appBar: AppBar(
        title: const Text('Contacts'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'Paramètres',
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => const SettingsPage()));
            },
          ),
        ],
      ),
      // Corps de la page
      body: Column(
        children: [
          // Barre de recherche
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Rechercher un contact',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          // Liste des contacts groupés
          Expanded(
            child: grouped.isEmpty
                ? const Center(child: Text('Aucun contact trouvé.'))
                : ListView(
              children: grouped.entries.map((entry) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // En-tête du groupe
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Text(
                        entry.key,
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ),
                    // Cartes pour chaque contact
                    ...entry.value.map((contact) {
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 2,
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: Colors.blue.shade200,
                            child: Text(contact.nom[0].toUpperCase()),
                          ),
                          title: Text(contact.nom),
                          subtitle: Text("${contact.email}\n${contact.tel}"),
                          isThreeLine: true,
                          trailing: IconButton(
                            icon: Icon(
                              contact.favorite == 1 ? Icons.star : Icons.star_border,
                              color: contact.favorite == 1 ? Colors.amber : Colors.grey,
                            ),
                            onPressed: () => _toggleFavorite(contact),
                          ),
                          onTap: () {
                            showModalBottomSheet(
                              context: context,
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
                              ),
                              builder: (_) => Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  ListTile(
                                    leading: const Icon(Icons.edit),
                                    title: const Text('Modifier'),
                                    onTap: () {
                                      Navigator.pop(context);
                                      _showUpdateDialog(contact);
                                    },
                                  ),
                                  ListTile(
                                    leading: const Icon(Icons.delete),
                                    title: const Text('Supprimer'),
                                    onTap: () {
                                      Navigator.pop(context);
                                      _deleteContact(contact.id!);
                                    },
                                  ),
                                  ListTile(
                                    leading: const Icon(Icons.phone),
                                    title: const Text('Appeler'),
                                    onTap: () {
                                      Navigator.pop(context);
                                      _callContact(contact.tel);
                                    },
                                  ),
                                  ListTile(
                                    leading: const Icon(Icons.email),
                                    title: const Text('Envoyer Email'),
                                    onTap: () {
                                      Navigator.pop(context);
                                      _emailContact(contact.email);
                                    },
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      );
                    }).toList(),
                  ],
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}
