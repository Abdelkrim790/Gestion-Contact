// Classe représentant un contact
class Contact {
  final int? id;

  // Informations du contact
  final String nom;
  final String email;
  final String tel;

  // Statut favori : 0 = non favori, 1 = favori
  int favorite;

  // Constructeur
  Contact({
    this.id,
    required this.nom,
    required this.email,
    required this.tel,
    this.favorite = 0,
  });


  // Conversion Contact → Map (pour SQLite)
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nom': nom,
      'email': email,
      'tel': tel,
      'favorite': favorite,
    };
  }

  // Conversion Map → Contact (depuis SQLite)
  factory Contact.fromMap(Map<String, dynamic> map) {
    return Contact(
      id: map['id'],
      nom: map['nom'],
      email: map['email'],
      tel: map['tel'],
      favorite: map['favorite'] ?? 0,
    );
  }
}
